/*
SQLyog Enterprise v12.08 (64 bit)
MySQL - 5.5.53 : Database - my_blog_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`my_blog_db` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `my_blog_db`;

/*Table structure for table `comments` */

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `comments` */

insert  into `comments`(`comment_id`,`user_id`,`post_id`,`comment`,`date_added`) values (2,2,10,'Hi, this is a comment. Thanks for this nice post. I like to see you blog. ','2014-08-26 23:38:00'),(3,4,10,'Oh, thanks for reading this blog. Thanks for being with me.','2014-08-26 23:39:05'),(4,6,10,'hhhh','2017-09-22 22:37:07');

/*Table structure for table `posts` */

DROP TABLE IF EXISTS `posts`;

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `post` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `active` int(11) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `posts` */

insert  into `posts`(`post_id`,`post_title`,`post`,`active`,`date_added`,`user_id`) values (1,'Post 1','post1-------------111111111111111111111',1,'2014-08-18 19:29:30',1),(2,'Post 2','post2----------xxxxxxxxxxxxxxxxxxxxxxxxx',1,'2014-08-18 19:50:17',0),(3,'Post 3','post3----------xxxxxxxxxxxxxxxxxxxxxxxxx',1,'2014-08-18 19:50:36',0),(4,'Post 4 ','post4----------xxxxxxxxxxxxxxxxxxxxxxxxx',1,'2014-08-19 02:23:29',0),(5,'Post 5','post5----------xxxxxxxxxxxxxxxxxxxxxxxxx',1,'2014-08-19 02:23:40',0),(6,'Post 6','post6----------xxxxxxxxxxxxxxxxxxxxxxxxx',1,'2014-08-19 02:23:49',0),(7,'Post 7','post7---------xxxxxxxxxxxxxxxxxxxxxxxxx',1,'2014-08-19 02:24:00',0),(8,'Post 8','post8----------xxxxxxxxxxxxxxxxxxxxxxxxx',1,'2014-08-19 02:24:11',0);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(4) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` enum('admin','author','user') NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`user_id`,`email`,`username`,`password`,`user_type`) values (5,'chand@gmail.com','chand','6f4a9c7287503510eb9ab662ed116c0272bf4ae1','user'),(6,'4234@qq.com','knight','c22c169b862d0e3f8555cadd2eaacb33ae0ed0dd','user'),(7,'34453@qq.com','zhoulong','c22c169b862d0e3f8555cadd2eaacb33ae0ed0dd','admin');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
