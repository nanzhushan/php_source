/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.6.28-log : Database - myblog
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`myblog` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `myblog`;

/*Table structure for table `myblog` */

DROP TABLE IF EXISTS `myblog`;

CREATE TABLE `myblog` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL,
  `dates` date DEFAULT NULL,
  `contents` text,
  `hits` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `myblog` */

insert  into `myblog`(`id`,`title`,`dates`,`contents`,`hits`) values (9,'aa','2017-09-22','<p>aa</p>\r\n',NULL),(10,'bb','2017-09-22','<p>bb</p>\r\n',NULL),(11,'cc','2017-09-22','<p>cc</p>\r\n',NULL),(12,'dd','2017-09-22','<p>dd</p>\r\n',NULL);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `uid` int(5) NOT NULL AUTO_INCREMENT,
  `uname` varchar(10) DEFAULT NULL,
  `upawd` varchar(100) DEFAULT NULL,
  `phone` float DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`uid`,`uname`,`upawd`,`phone`,`email`) values (2,'knight','Kq6ZIIk2t+ohy8JFF4Xo7mqETB9iqxENoehMdL/45Waja279wPdV1AOODWOwO8J/auncML1L2Fu6we3wTOsOuw==',18038000000,'10000@qq.com'),(3,'knight','0/yL8VIC9VdWqFT/Byst25DBAv3TlEd9DYR2mD2na1/UHo80Nu5XA0HG8mifo8ixtVXTQnefFdF0e1ao1aX/cw==',18038000000,'10000@qq.com'),(4,'aa','lFxO+kwM+3mV565HKXjhN2KCsOVGYYna465ux4Vdn0YxfwySxve3xNMLuyiQ05wIZaUFG71/Gwf3vkiRQF1sJg==',5345340,'43454'),(5,'admin','EDww7gPBezoB6t8tRvpqzmowiK3HsTU1c/r4TUkJh9FgfSjDIjhKCViedJq5SnSY/KsNzOnnKN2AyZSnOgKQ8g==',4241,'dsfsaf'),(6,'test','tTJZDypCVQ9Il9Bf2Ya+pS+lrlHt6uiceFFk4nEmTb0vr7Ms8R2j9GuPjP4RWS5zdfT+BEuFDBSAjw6m7eaHmw==',1818850,'tt'),(7,'ppp','GLPSVA4Kbr6TzjjGtiMBLWRSnV6UcG6YSc8Zt/thFfgi1kg3s+r896l7Xqg89y3GkgYPajXDY37zkYpP4PwkDw==',54325,'5325');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
